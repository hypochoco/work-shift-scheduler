
submission command: `zip -r project.zip * -x "./p2_venv/*"`
